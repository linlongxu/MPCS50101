# module-1-debugging.py
#
# Fix the code so that it executes and prints correctly


print ("Hello World")

x = 5

y = 9

print (f"my favorite number is {y}")

# Make the following line print: I love apples
print("I love apples")

z = 4 + (6 - 2) / 5 % 3
print(z)

print("I said eat your veggies to my kids.")

print("There are {} carrots left".format(3))

print("This line is indented too far.")

print("The \\n is very efficient when making a newline in the same print statement.")

